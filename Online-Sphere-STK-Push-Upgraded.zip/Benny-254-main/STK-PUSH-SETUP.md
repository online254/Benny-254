# Online Sphere — STK Push deployment notes

This project includes a browser UI and a Node/Express Daraja backend. The UI can
request an STK Push, but the real prompt will only work after the backend is
deployed and valid Safaricom Daraja credentials are configured.

## 1. Deploy the backend to Render
1. Push this folder to a GitHub repository.
2. Create a Render **Web Service** from that repository.
3. Use `npm install` as the build command and `npm start` as the start command.
4. Copy the exact public service URL shown by Render.

## 2. Set Render environment variables
In Render → your service → Environment, add:
- `MPESA_ENV` = `sandbox` while testing; use `production` only after Safaricom has approved your live shortcode/product.
- `MPESA_CONSUMER_KEY` = your Daraja app Consumer Key
- `MPESA_CONSUMER_SECRET` = your Daraja app Consumer Secret
- `MPESA_SHORTCODE` = the shortcode assigned to your Daraja product
- `MPESA_PASSKEY` = the passkey for that shortcode/product
- `MPESA_CALLBACK_URL` = `https://YOUR-EXACT-RENDER-SERVICE.onrender.com/api/mpesa/callback`
- `ALLOWED_ORIGINS` = the exact deployed frontend origin, e.g. `https://your-site.netlify.app` (comma-separate multiple origins)
- `NODE_ENV` = `production`

Do not upload `.env` or expose credentials in frontend files. The `.env` file was
intentionally excluded from this upgraded ZIP. Use Render's environment settings.

## 3. Point the website at the backend
Edit `public/config.js` and set `ONLINE_SPHERE_API_BASE` to the exact Render URL,
without `/api/...` at the end. Example:
`window.ONLINE_SPHERE_API_BASE = "https://your-service.onrender.com";`

Redeploy the frontend (Netlify, if used). The API base URL must match your actual
Render service URL; the default value in `config.js` is only a placeholder based
on the service name in `render.yaml`.

## 4. Test in this order
1. Open `https://YOUR-EXACT-RENDER-SERVICE.onrender.com/health`. It should report
   that configuration checks pass. This check does not itself prove Daraja login.
2. Open `https://YOUR-EXACT-RENDER-SERVICE.onrender.com/api/mpesa/test-auth`.
   It should return HTTP 200 and `"status":"authenticated"`. If it fails, review
   the Render logs and check the environment, shortcode and credentials.
3. Submit a small sandbox payment from the website using a Daraja sandbox test
   number and the package values configured in the backend.
4. Confirm the callback reaches `/api/mpesa/callback` in the Render logs.

## Important limitations
- The backend currently sends a Daraja STK Push and logs callbacks. It does not
  persist payments, reconcile receipts, activate memberships, or update balances.
  Do not treat a successful HTTP response as proof of payment.
- The current backend assumes `CustomerPayBillOnline`; this is appropriate only
  for a PayBill configuration. A Till/Buy Goods setup needs its correct Daraja
  transaction type and shortcode configuration.
- The package prices are defined server-side in `server.js` (Bronze 1000, Silver
  1750, Gold 2500 KSh). The server, not the browser, determines the amount.
- A real production prompt cannot be verified from this code alone; it requires
  valid Safaricom credentials, an approved shortcode/product, correct callback
  URL, and matching CORS origin.
