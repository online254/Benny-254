/*
 * Online Sphere API configuration.
 * Replace the URL below with the exact public URL shown for your Render
 * backend service. Do not put Daraja credentials in this file.
 */
window.ONLINE_SPHERE_API_BASE = "https://online-sphere-backend.onrender.com";
