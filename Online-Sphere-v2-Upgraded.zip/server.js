require("dotenv").config();

const express = require("express");
const path = require("path");
const crypto = require("crypto");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = Number(process.env.PORT || 3000);
const DB_PATH = process.env.DB_PATH || path.join(__dirname, "database", "online-sphere.db");
const PUBLIC_DIR = path.join(__dirname, "public");

app.use(express.json({ limit: "100kb" }));
app.use(express.urlencoded({ extended: true }));
app.disable("x-powered-by");

const PACKAGES = Object.freeze({ Bronze: 1000, Silver: 1750, Gold: 2500 });
const DARAJA_BASE_URL = process.env.MPESA_ENV === "production"
  ? "https://api.safaricom.co.ke"
  : "https://sandbox.safaricom.co.ke";

const db = new sqlite3.Database(DB_PATH);

db.serialize(() => {
  db.run("PRAGMA foreign_keys = ON");
  db.run("PRAGMA journal_mode = WAL");
});

function run(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.run(sql, params, function (err) {
      if (err) reject(err);
      else resolve({ id: this.lastID, changes: this.changes });
    });
  });
}
function get(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.get(sql, params, (err, row) => err ? reject(err) : resolve(row));
  });
}
function all(sql, params = []) {
  return new Promise((resolve, reject) => {
    db.all(sql, params, (err, rows) => err ? reject(err) : resolve(rows));
  });
}
function nowIso() { return new Date().toISOString(); }
function randomToken() { return crypto.randomBytes(32).toString("hex"); }
function hashToken(token) { return crypto.createHash("sha256").update(token).digest("hex"); }
function normalizeEmail(email) { return String(email || "").trim().toLowerCase(); }
function normalizePhone(phone) {
  let p = String(phone || "").replace(/\s+/g, "").replace(/^\+/, "");
  if (p.startsWith("07") || p.startsWith("01")) p = "254" + p.slice(1);
  return p;
}
function validPhone(phone) { return /^254[17]\d{8}$/.test(phone); }
function createTimestamp() {
  const d = new Date();
  const parts = [d.getFullYear(), d.getMonth() + 1, d.getDate(), d.getHours(), d.getMinutes(), d.getSeconds()]
    .map((v, i) => i === 0 ? String(v) : String(v).padStart(2, "0"));
  return parts.join("");
}
function hashPassword(password) {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString("hex");
    crypto.scrypt(password, salt, 64, (err, derived) => {
      if (err) reject(err);
      else resolve(`${salt}:${derived.toString("hex")}`);
    });
  });
}
function verifyPassword(password, stored) {
  return new Promise((resolve, reject) => {
    const [salt, key] = String(stored || "").split(":");
    if (!salt || !key) return resolve(false);
    crypto.scrypt(password, salt, 64, (err, derived) => {
      if (err) return reject(err);
      const a = Buffer.from(key, "hex");
      const b = Buffer.from(derived.toString("hex"), "hex");
      resolve(a.length === b.length && crypto.timingSafeEqual(a, b));
    });
  });
}

async function initDatabase() {
  const schema = require("fs").readFileSync(path.join(__dirname, "database", "schema.sql"), "utf8");
  const statements = schema.split(/;\s*(?:\r?\n|$)/).map(s => s.trim()).filter(Boolean);
  for (const statement of statements) await run(statement);
}

async function createSession(userId) {
  const token = randomToken();
  const tokenHash = hashToken(token);
  const days = Number(process.env.SESSION_DAYS || 30);
  const expires = new Date(Date.now() + days * 86400000).toISOString();
  await run("INSERT INTO sessions (user_id, token_hash, expires_at) VALUES (?, ?, ?)", [userId, tokenHash, expires]);
  return token;
}

async function auth(req, res, next) {
  try {
    const header = req.get("authorization") || "";
    const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
    if (!token) return res.status(401).json({ success: false, message: "Authentication required." });
    const session = await get(`SELECT s.*, u.full_name, u.email, u.phone
      FROM sessions s JOIN users u ON u.id=s.user_id
      WHERE s.token_hash=? AND s.expires_at > ?`, [hashToken(token), nowIso()]);
    if (!session) return res.status(401).json({ success: false, message: "Session expired or invalid." });
    req.user = { id: session.user_id, fullName: session.full_name, email: session.email, phone: session.phone };
    next();
  } catch (e) { next(e); }
}

async function getAccount(userId) {
  return get("SELECT * FROM accounts WHERE user_id=?", [userId]);
}

async function getAccessToken() {
  const key = process.env.MPESA_CONSUMER_KEY;
  const secret = process.env.MPESA_CONSUMER_SECRET;
  if (!key || !secret) throw new Error("M-Pesa API credentials are not configured.");
  const credentials = Buffer.from(`${key}:${secret}`).toString("base64");
  const response = await fetch(`${DARAJA_BASE_URL}/oauth/v1/generate?grant_type=client_credentials`, {
    headers: { Authorization: `Basic ${credentials}`, Accept: "application/json" }
  });
  const data = await response.json();
  if (!response.ok || !data.access_token) throw new Error(data.errorMessage || "Unable to obtain M-Pesa access token.");
  return data.access_token;
}

async function sendStkPush({ phone, packageName, amount, reference }) {
  const shortcode = process.env.MPESA_SHORTCODE;
  const passkey = process.env.MPESA_PASSKEY;
  const callbackUrl = process.env.MPESA_CALLBACK_URL;
  if (!shortcode || !passkey || !callbackUrl) throw new Error("M-Pesa shortcode, passkey or callback URL is not configured.");
  const accessToken = await getAccessToken();
  const timestamp = createTimestamp();
  const password = Buffer.from(`${shortcode}${passkey}${timestamp}`).toString("base64");
  const payload = {
    BusinessShortCode: shortcode,
    Password: password,
    Timestamp: timestamp,
    TransactionType: "CustomerPayBillOnline",
    Amount: amount,
    PartyA: phone,
    PartyB: shortcode,
    PhoneNumber: phone,
    CallBackURL: callbackUrl,
    AccountReference: reference,
    TransactionDesc: `Online Sphere ${packageName} Membership`
  };
  const response = await fetch(`${DARAJA_BASE_URL}/mpesa/stkpush/v1/processrequest`, {
    method: "POST",
    headers: { Authorization: `Bearer ${accessToken}`, "Content-Type": "application/json", Accept: "application/json" },
    body: JSON.stringify(payload)
  });
  const data = await response.json();
  if (!response.ok || data.ResponseCode !== "0") throw new Error(data.errorMessage || data.ResponseDescription || "Safaricom rejected the STK request.");
  return data;
}

app.get("/", (req, res) => res.sendFile(path.join(PUBLIC_DIR, "index.html")));
app.get("/health", async (req, res) => {
  const row = await get("SELECT COUNT(*) AS users FROM users");
  res.json({ success: true, service: "Online Sphere", status: "ok", users: row.users, time: nowIso() });
});
app.get("/api/package/:packageName", (req, res) => {
  const amount = PACKAGES[req.params.packageName];
  if (!amount) return res.status(400).json({ success: false, message: "Invalid membership package." });
  res.json({ success: true, package: req.params.packageName, amount });
});

app.post("/api/auth/register", async (req, res, next) => {
  try {
    const fullName = String(req.body.fullName || "").trim();
    const email = normalizeEmail(req.body.email);
    const phone = normalizePhone(req.body.phone);
    const password = String(req.body.password || "");
    if (fullName.length < 2) return res.status(400).json({ success: false, message: "Enter your full name." });
    if (!/^\S+@\S+\.\S+$/.test(email)) return res.status(400).json({ success: false, message: "Enter a valid email address." });
    if (!validPhone(phone)) return res.status(400).json({ success: false, message: "Enter a valid Kenyan M-Pesa number." });
    if (password.length < 8) return res.status(400).json({ success: false, message: "Password must be at least 8 characters." });
    const existing = await get("SELECT id FROM users WHERE email=? OR phone=?", [email, phone]);
    if (existing) return res.status(409).json({ success: false, message: "An account with that email or phone already exists." });
    const passwordHash = await hashPassword(password);
    const accountNumber = `OS-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
    const user = await run("INSERT INTO users (full_name,email,phone,password_hash) VALUES (?,?,?,?)", [fullName, email, phone, passwordHash]);
    await run("INSERT INTO accounts (user_id,account_number) VALUES (?,?)", [user.id, accountNumber]);
    const token = await createSession(user.id);
    res.status(201).json({ success: true, token, user: { id: user.id, fullName, email, phone }, account: { accountNumber } });
  } catch (e) { next(e); }
});

app.post("/api/auth/login", async (req, res, next) => {
  try {
    const email = normalizeEmail(req.body.email);
    const password = String(req.body.password || "");
    const user = await get("SELECT * FROM users WHERE email=?", [email]);
    if (!user || !(await verifyPassword(password, user.password_hash))) return res.status(401).json({ success: false, message: "Invalid email or password." });
    const token = await createSession(user.id);
    res.json({ success: true, token, user: { id: user.id, fullName: user.full_name, email: user.email, phone: user.phone } });
  } catch (e) { next(e); }
});

app.post("/api/auth/logout", auth, async (req, res, next) => {
  try {
    const header = req.get("authorization") || "";
    await run("DELETE FROM sessions WHERE token_hash=?", [hashToken(header.slice(7).trim())]);
    res.json({ success: true });
  } catch (e) { next(e); }
});

app.get("/api/auth/me", auth, async (req, res, next) => {
  try {
    const account = await getAccount(req.user.id);
    res.json({ success: true, user: req.user, account });
  } catch (e) { next(e); }
});

app.get("/api/opportunities", async (req, res, next) => {
  try {
    const q = String(req.query.search || "").trim();
    const category = String(req.query.category || "").trim();
    let sql = "SELECT * FROM opportunities WHERE status='active'";
    const params = [];
    if (q) { sql += " AND (title LIKE ? OR description LIKE ? OR category LIKE ?)"; const x = `%${q}%`; params.push(x, x, x); }
    if (category) { sql += " AND category=?"; params.push(category); }
    sql += " ORDER BY featured DESC, created_at DESC";
    const opportunities = await all(sql, params);
    res.json({ success: true, opportunities });
  } catch (e) { next(e); }
});

app.get("/api/opportunities/:id", async (req, res, next) => {
  try {
    const opportunity = await get("SELECT * FROM opportunities WHERE id=? AND status='active'", [req.params.id]);
    if (!opportunity) return res.status(404).json({ success: false, message: "Opportunity not found." });
    res.json({ success: true, opportunity });
  } catch (e) { next(e); }
});

app.post("/api/opportunities/:id/save", auth, async (req, res, next) => {
  try {
    await run("INSERT OR IGNORE INTO saved_opportunities (user_id, opportunity_id) VALUES (?,?)", [req.user.id, req.params.id]);
    res.json({ success: true, message: "Opportunity saved." });
  } catch (e) { next(e); }
});

app.get("/api/transactions", auth, async (req, res, next) => {
  try {
    const transactions = await all("SELECT id,type,amount,status,reference,description,created_at FROM transactions WHERE user_id=? ORDER BY created_at DESC LIMIT 50", [req.user.id]);
    res.json({ success: true, transactions });
  } catch (e) { next(e); }
});

app.post("/api/account/activate", auth, async (req, res, next) => {
  try {
    const packageName = String(req.body.packageName || "");
    const amount = PACKAGES[packageName];
    if (!amount) return res.status(400).json({ success: false, message: "Invalid membership package." });
    const account = await getAccount(req.user.id);
    if (!account) return res.status(404).json({ success: false, message: "Account not found." });
    if (account.status === "active") return res.status(409).json({ success: false, message: "Your account is already active." });
    const pending = await get("SELECT * FROM transactions WHERE user_id=? AND type='activation' AND status='pending' ORDER BY created_at DESC LIMIT 1", [req.user.id]);
    if (pending) return res.status(409).json({ success: false, message: `You already have a pending activation payment (${pending.reference}).`, reference: pending.reference });
    const reference = `OS-${Date.now()}-${crypto.randomBytes(2).toString("hex").toUpperCase()}`;
    const tx = await run("INSERT INTO transactions (user_id,account_id,type,amount,status,reference,description) VALUES (?,?,?,?,?,?,?)", [req.user.id, account.id, "activation", amount, "pending", reference, `${packageName} membership activation`]);
    try {
      const stk = await sendStkPush({ phone: req.user.phone, packageName, amount, reference });
      await run("UPDATE transactions SET merchant_request_id=?, checkout_request_id=? WHERE id=?", [stk.MerchantRequestID || null, stk.CheckoutRequestID || null, tx.id]);
      res.json({ success: true, message: "STK Push sent. Check your phone and enter your M-Pesa PIN.", reference, package: packageName, amount, checkoutRequestID: stk.CheckoutRequestID });
    } catch (paymentError) {
      await run("UPDATE transactions SET status='failed', description=? WHERE id=?", [paymentError.message, tx.id]);
      return res.status(502).json({ success: false, message: paymentError.message, reference });
    }
  } catch (e) { next(e); }
});

app.post("/api/mpesa/stkpush", auth, async (req, res) => {
  return res.status(400).json({ success: false, message: "Use /api/account/activate to start a membership payment." });
});

app.post("/api/mpesa/callback", async (req, res, next) => {
  try {
    const callback = req.body?.Body?.stkCallback;
    if (!callback) return res.json({ ResultCode: 0, ResultDesc: "Accepted" });
    const checkoutId = callback.CheckoutRequestID;
    const tx = await get("SELECT * FROM transactions WHERE checkout_request_id=?", [checkoutId]);
    if (!tx) return res.json({ ResultCode: 0, ResultDesc: "Accepted" });
    if (tx.status !== "pending") return res.json({ ResultCode: 0, ResultDesc: "Already processed" });

    if (Number(callback.ResultCode) !== 0) {
      await run("UPDATE transactions SET status='failed', description=? WHERE id=? AND status='pending'", [callback.ResultDesc || "M-Pesa payment was not completed.", tx.id]);
      return res.json({ ResultCode: 0, ResultDesc: "Accepted" });
    }

    const items = callback.CallbackMetadata?.Item || [];
    const payment = Object.fromEntries(items.map(item => [item.Name, item.Value]));
    const receipt = payment.MpesaReceiptNumber ? String(payment.MpesaReceiptNumber) : null;
    const paidAmount = Number(payment.Amount || 0);
    if (paidAmount !== Number(tx.amount)) {
      await run("UPDATE transactions SET status='review', description=? WHERE id=?", ["Amount mismatch in M-Pesa callback.", tx.id]);
      return res.json({ ResultCode: 0, ResultDesc: "Accepted" });
    }

    await run("BEGIN IMMEDIATE TRANSACTION");
    try {
      await run("UPDATE transactions SET status='completed', provider_reference=? WHERE id=? AND status='pending'", [receipt, tx.id]);
      await run("UPDATE accounts SET status='active', package=(SELECT CASE amount WHEN 1000 THEN 'Bronze' WHEN 1750 THEN 'Silver' WHEN 2500 THEN 'Gold' END FROM transactions WHERE id=?), activation_fee=?, updated_at=CURRENT_TIMESTAMP WHERE id=?", [tx.id, paidAmount, tx.account_id]);
      await run("COMMIT");
    } catch (e) { await run("ROLLBACK"); throw e; }
    res.json({ ResultCode: 0, ResultDesc: "Accepted" });
  } catch (e) { next(e); }
});

app.use(express.static(PUBLIC_DIR, { extensions: ["html"] }));
app.use((err, req, res, next) => {
  console.error(err);
  if (res.headersSent) return next(err);
  res.status(500).json({ success: false, message: "An unexpected server error occurred." });
});

initDatabase()
  .then(() => app.listen(PORT, () => console.log(`Online Sphere running on port ${PORT}`)))
  .catch(err => { console.error("Database initialization failed:", err); process.exit(1); });
