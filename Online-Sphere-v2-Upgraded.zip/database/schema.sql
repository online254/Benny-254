PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  full_name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT UNIQUE,
  password_hash TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS accounts (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL UNIQUE,
  account_number TEXT UNIQUE NOT NULL,
  package TEXT,
  activation_fee INTEGER DEFAULT 0,
  status TEXT DEFAULT 'inactive' CHECK(status IN ('inactive','pending','active','suspended')),
  balance INTEGER DEFAULT 0,
  total_earned INTEGER DEFAULT 0,
  total_withdrawn INTEGER DEFAULT 0,
  pending_withdrawal INTEGER DEFAULT 0,
  currency TEXT DEFAULT 'KES',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS packages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT UNIQUE NOT NULL,
  activation_fee INTEGER NOT NULL,
  description TEXT,
  status TEXT DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  account_id INTEGER NOT NULL,
  type TEXT NOT NULL,
  amount INTEGER NOT NULL,
  status TEXT DEFAULT 'pending',
  reference TEXT UNIQUE,
  merchant_request_id TEXT,
  checkout_request_id TEXT UNIQUE,
  provider_reference TEXT,
  description TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS opportunities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  difficulty TEXT DEFAULT 'Beginner',
  earning_model TEXT,
  requirements TEXT,
  platform_name TEXT,
  external_url TEXT,
  risk_level TEXT DEFAULT 'Low',
  featured INTEGER DEFAULT 0,
  status TEXT DEFAULT 'active',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS saved_opportunities (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  opportunity_id INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, opportunity_id),
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(opportunity_id) REFERENCES opportunities(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS withdrawals (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  account_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  method TEXT NOT NULL,
  phone TEXT,
  reference TEXT UNIQUE,
  status TEXT DEFAULT 'pending',
  notes TEXT,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  processed_at DATETIME,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY(account_id) REFERENCES accounts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at DATETIME NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_transactions_user_created ON transactions(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_transactions_checkout ON transactions(checkout_request_id);
CREATE INDEX IF NOT EXISTS idx_opportunities_status_featured ON opportunities(status, featured);

INSERT OR IGNORE INTO packages(name, activation_fee, description) VALUES
('Bronze',1000,'Basic access to Online Sphere opportunities and learning resources.'),
('Silver',1750,'Expanded access to opportunities and advanced learning resources.'),
('Gold',2500,'Full access to the Online Sphere opportunity and learning library.');

INSERT OR IGNORE INTO opportunities(title,category,description,difficulty,earning_model,requirements,risk_level,featured) VALUES
('Online Transcription','Transcription','Convert audio or video recordings into written text.','Beginner','Paid per task or audio minute','Good listening skills, typing and attention to detail.','Low',1),
('Data Entry','Data Entry','Enter, organize and verify information using online tools.','Beginner','Paid per task or project','Basic computer skills and accuracy.','Low',1),
('Freelancing','Freelancing','Offer professional skills to clients locally or internationally.','Beginner-Advanced','Paid per project or contract','A marketable skill and a professional profile.','Low',1),
('Academic Research Assistance','Research','Provide legitimate research support while following academic integrity rules.','Intermediate','Paid per project','Research, writing and citation skills.','Medium',0),
('Online Gaming','Gaming','Explore legitimate gaming-related opportunities such as game testing, streaming and content creation.','Beginner','Task, contract, content or platform based','Gaming or content creation ability.','Medium',0),
('Content Creation','Content','Create useful digital content for websites and social platforms.','Beginner-Advanced','Paid per project, contract or platform','Writing, video, design or communication skills.','Low',1),
('Graphic Design','Design','Create logos, social media graphics, posters and other digital designs.','Intermediate','Paid per project','Design skills and suitable software.','Low',0),
('AI-Assisted Work','AI','Explore legitimate work involving AI-assisted research, content, data and digital services.','Beginner-Advanced','Paid per task or project','Use AI responsibly and verify results.','Medium',1),
('Remote Jobs','Remote Jobs','Find legitimate remote employment and contract opportunities.','Intermediate','Salary, contract or project payment','Skills and qualifications depend on the job.','Low',1),
('Virtual Assistance','Virtual Assistance','Support clients with scheduling, communication, research and administrative tasks.','Beginner-Intermediate','Paid per project or contract','Organization, communication and basic digital skills.','Low',0),
('Translation','Translation','Translate digital content between languages accurately and naturally.','Intermediate','Paid per word, task or project','Strong command of the relevant languages.','Low',0),
('Social Media Management','Social Media','Plan, create and manage digital content for brands and organizations.','Intermediate','Paid per project or monthly contract','Content, communication and analytics skills.','Low',0);
